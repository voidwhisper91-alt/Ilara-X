package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"runtime/debug"
	"strconv"
	"strings"
	"syscall"
	"time"

	// DNS for Android (no /etc/resolv.conf there); a package so `go build main.go` includes it too
	_ "gemini-server/pkg/androiddns"
	"gemini-server/pkg/checkpoint"
	"gemini-server/pkg/claude"
	"gemini-server/pkg/codex"
	"gemini-server/pkg/config"
	"gemini-server/pkg/handlers"
	"gemini-server/pkg/hub"
	"gemini-server/pkg/memory"
	"gemini-server/pkg/opencode"
	"gemini-server/pkg/plugins"
	"gemini-server/pkg/relocate"
	"gemini-server/pkg/runlog"
	"gemini-server/pkg/security"
	"gemini-server/pkg/ws"
)

func printUsage() {
	fmt.Println(`antiGem Go IDE Server & AGY Hub Supervisor

Usage:
  go run main.go [flags]

Flags:
  -u, --unpatch             Unpatch AGY binary back to standard header and exit (do not start server)
  --bin <path>              Custom path to AGY binary (for --unpatch or custom setups)
  --claude-bin <path>       Custom path to the Claude Code CLI (default: claude on PATH)
  --opencode-bin <path>     Custom path to the OpenCode CLI (default: opencode on PATH or ~/.opencode/bin)
  --codex-bin <path>        Custom path to the Codex CLI (default: codex on PATH or ~/.local/bin)
  -t, --token <token>       12-character security token for API & AGY CSRF obfuscation
  -f, --force, --f          Force start AGY Hub automatically without prompting
  -p, --port <port>         Port for the Go IDE Server (default: 1234)
  --bind <address>          Address the IDE Server listens on (default: 127.0.0.1; use 0.0.0.0 only to reach it directly from other machines)
  --hub-port <port>         Port for the AGY Hub RPC server (default: 1235)
  --tz-offset <seconds>     Timezone offset in seconds (e.g. 20700 for UTC+05:45)
  --tz <location>           Timezone location name (e.g. Asia/Kathmandu)
  --no-hub                  Skip launching AGY Hub (run IDE server only)
  --no-claude               Disable Claude Code (no /api/claude endpoints, never runs the claude CLI)
  --no-opencode             Disable OpenCode (no /api/opencode endpoints, never runs the opencode CLI)
  --no-codex                Disable Codex (no /api/codex endpoints, never runs the codex CLI)
  -d, --dir <path>          Custom workspace directory
  -h, --help                Show help documentation`)
}

// statusRecorder intercepts HTTP status code and response body for logging and error reporting
type statusRecorder struct {
	http.ResponseWriter
	statusCode   int
	responseBody bytes.Buffer
	wroteHeader  bool
}

func (r *statusRecorder) WriteHeader(code int) {
	if !r.wroteHeader {
		r.statusCode = code
		r.wroteHeader = true
		r.ResponseWriter.WriteHeader(code)
	}
}

// Flush lets streaming handlers (git clone progress) push each line to the client right away.
func (r *statusRecorder) Flush() {
	if f, ok := r.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

// Unwrap exposes the real writer to http.ResponseController.
func (r *statusRecorder) Unwrap() http.ResponseWriter { return r.ResponseWriter }

func (r *statusRecorder) Write(b []byte) (int, error) {
	if !r.wroteHeader {
		r.WriteHeader(http.StatusOK)
	}
	if r.responseBody.Len() < 4096 {
		r.responseBody.Write(b)
	}
	return r.ResponseWriter.Write(b)
}

// formatHumanCrash converts raw runtime panics and stacks into human-readable diagnostics
func formatHumanCrash(p interface{}, rawStack []byte) (reason string, location string) {
	reason = fmt.Sprintf("%v", p)
	switch {
	case strings.Contains(reason, "invalid memory address") || strings.Contains(reason, "nil pointer"):
		reason = "Nil Pointer / Missing Object (tried to access data that was not initialized)"
	case strings.Contains(reason, "index out of range"):
		reason = "Array/Slice Index Out Of Range (tried to read beyond array length)"
	case strings.Contains(reason, "slice bounds out of range"):
		reason = "Slice Bounds Out Of Range"
	case strings.Contains(reason, "concurrent map"):
		reason = "Concurrent Map Access Collision"
	}

	lines := strings.Split(string(rawStack), "\n")
	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if (strings.Contains(line, "gemini-server/pkg/") || strings.Contains(line, "gemini-server/main.go")) && !strings.Contains(line, "recoveryHandler") {
			if i+1 < len(lines) && strings.Contains(lines[i+1], ".go:") {
				fileLoc := strings.TrimSpace(lines[i+1])
				if idx := strings.Index(fileLoc, " +0x"); idx != -1 {
					fileLoc = fileLoc[:idx]
				}
				funcName := line
				if idx := strings.LastIndex(funcName, "/"); idx != -1 {
					funcName = funcName[idx+1:]
				}
				return reason, fmt.Sprintf("%s (in %s)", fileLoc, funcName)
			}
			return reason, line
		}
	}
	return reason, "Unknown internal code location"
}

func main() {
	// `agy_ide_bridge relocate-debs …`: AntiGem's apt hook and dpkg wrapper rewrite Termux .debs with it (see
	// pkg/relocate); nothing of the bridge itself starts
	if len(os.Args) > 1 && os.Args[1] == "relocate-debs" {
		os.Exit(relocate.Main(os.Args[2:], os.Stdin, os.Stdout, os.Stderr))
	}

	cfg := config.LoadConfig()

	var unpatchOnly bool
	var customAgyBin string
	var customClaudeBin string
	var noClaude bool
	var customOpenCodeBin string
	var noOpenCode bool
	var customCodexBin string
	var noCodex bool
	var forceStart bool
	var skipHub bool
	var cliToken string
	var tzOffsetSec int
	var tzName string
	hubPort := "1235"

	// Parse command line arguments
	for i := 1; i < len(os.Args); i++ {
		arg := os.Args[i]
		switch {
		case arg == "-u" || arg == "--unpatch":
			unpatchOnly = true
		case strings.HasPrefix(arg, "--bin="):
			customAgyBin = strings.TrimPrefix(arg, "--bin=")
		case arg == "--bin" || arg == "--agy-bin":
			if i+1 < len(os.Args) {
				customAgyBin = os.Args[i+1]
				i++
			}
		case strings.HasPrefix(arg, "--claude-bin="):
			customClaudeBin = strings.TrimPrefix(arg, "--claude-bin=")
		case arg == "--claude-bin":
			if i+1 < len(os.Args) {
				customClaudeBin = os.Args[i+1]
				i++
			}
		case strings.HasPrefix(arg, "--token="):
			cliToken = strings.TrimPrefix(arg, "--token=")
		case arg == "-t" || arg == "--token":
			if i+1 < len(os.Args) {
				cliToken = os.Args[i+1]
				i++
			}
		case arg == "-f" || arg == "--f" || arg == "--force" || arg == "-force":
			forceStart = true
		case arg == "--no-hub" || arg == "-n" || arg == "--skip-hub":
			skipHub = true
		case arg == "--no-claude":
			noClaude = true
		case strings.HasPrefix(arg, "--opencode-bin="):
			customOpenCodeBin = strings.TrimPrefix(arg, "--opencode-bin=")
		case arg == "--opencode-bin":
			if i+1 < len(os.Args) {
				customOpenCodeBin = os.Args[i+1]
				i++
			}
		case arg == "--no-opencode":
			noOpenCode = true
		case strings.HasPrefix(arg, "--codex-bin="):
			customCodexBin = strings.TrimPrefix(arg, "--codex-bin=")
		case arg == "--codex-bin":
			if i+1 < len(os.Args) {
				customCodexBin = os.Args[i+1]
				i++
			}
		case arg == "--no-codex":
			noCodex = true
		case strings.HasPrefix(arg, "--port="):
			cfg.Port = strings.TrimPrefix(arg, "--port=")
		case arg == "-p" || arg == "--port":
			if i+1 < len(os.Args) {
				cfg.Port = os.Args[i+1]
				i++
			}
		case strings.HasPrefix(arg, "--bind="):
			cfg.Bind = strings.TrimPrefix(arg, "--bind=")
		case arg == "--bind":
			if i+1 < len(os.Args) {
				cfg.Bind = os.Args[i+1]
				i++
			}
		case strings.HasPrefix(arg, "--hub-port="):
			hubPort = strings.TrimPrefix(arg, "--hub-port=")
		case arg == "--hub-port":
			if i+1 < len(os.Args) {
				hubPort = os.Args[i+1]
				i++
			}
		case strings.HasPrefix(arg, "--tz-offset="):
			if val, err := strconv.Atoi(strings.TrimPrefix(arg, "--tz-offset=")); err == nil {
				tzOffsetSec = val
			}
		case arg == "--tz-offset":
			if i+1 < len(os.Args) {
				if val, err := strconv.Atoi(os.Args[i+1]); err == nil {
					tzOffsetSec = val
				}
				i++
			}
		case strings.HasPrefix(arg, "--tz="):
			tzName = strings.TrimPrefix(arg, "--tz=")
		case arg == "--tz":
			if i+1 < len(os.Args) {
				tzName = os.Args[i+1]
				i++
			}
		case strings.HasPrefix(arg, "--dir="):
			cfg.WorkspaceDir = strings.TrimPrefix(arg, "--dir=")
		case arg == "-d" || arg == "--dir" || arg == "--workspace":
			if i+1 < len(os.Args) {
				cfg.WorkspaceDir = os.Args[i+1]
				i++
			}
		case arg == "-h" || arg == "--help":
			printUsage()
			os.Exit(0)
		}
	}

	if unpatchOnly {
		resolvedBin, err := hub.ResolveAgyBinaryInteractive(customAgyBin, true)
		if err != nil {
			fmt.Printf("  \033[1;31m✗ Unpatch Failed:\033[0m %v\n", err)
			os.Exit(1)
		}
		patchTarget := hub.ResolvePatchTarget(resolvedBin)
		fmt.Println("\033[1;36m============================================================\033[0m")
		fmt.Println("\033[1;33m  ⚡ antiGem AGY Binary Header Unpatcher\033[0m")
		fmt.Println("\033[1;36m============================================================\033[0m")
		fmt.Printf("  \033[1m• Target Binary:\033[0m  %s\n", patchTarget)

		restoredHeader, elapsed, err := security.UnpatchAgyHeader(patchTarget)
		if err != nil {
			fmt.Printf("  \033[1;31m✗ Unpatch Failed:\033[0m %v\n", err)
			os.Exit(1)
		}
		fmt.Printf("  \033[1;32m✓ Unpatch Succeeded:\033[0m Header restored to standard '%s' in %v\n", restoredHeader, elapsed)
		fmt.Println("\033[1;36m============================================================\033[0m")
		os.Exit(0)
	}

	// Configure local timezone if offset or name is specified (or in environment)
	if tzOffsetSec == 0 {
		if envOff := os.Getenv("TZ_OFFSET"); envOff != "" {
			if val, err := strconv.Atoi(envOff); err == nil {
				tzOffsetSec = val
			}
		}
	}
	if tzOffsetSec != 0 {
		time.Local = time.FixedZone("Local", tzOffsetSec)
	} else if tzName != "" {
		if loc, err := time.LoadLocation(tzName); err == nil {
			time.Local = loc
		}
	}

	secToken := security.ResolveToken(cliToken)
	framedHeader := security.BuildFramedHeader(secToken)

	resolvedAgyBin, err := hub.ResolveAgyBinaryInteractive(customAgyBin, forceStart || skipHub)
	if customAgyBin != "" && err != nil {
		// the app always names the agy to use, also before it is installed (Settings → Antigravity CLI → Install):
		// keep that path and run without the hub until agy is there
		resolvedAgyBin = hub.ExpandAgyPath(customAgyBin)
		if !skipHub {
			fmt.Printf(" \033[33m[!] agy is not installed at %s yet: the AGY Hub starts once it is installed.\033[0m\n", resolvedAgyBin)
		}
	} else if err != nil && !skipHub {
		fmt.Printf(" \033[31m[!] AGY Discovery Warning:\033[0m %v\n", err)
	}

	// everything printed from here on also goes to ~/logs/agy-ide-bridge_<date>_<time>.log (one file per start)
	runLogFile := runlog.Start(cfg.HomeDir)

	// Stylized Banner
	fmt.Println("\033[1;36m============================================================\033[0m")
	fmt.Println("\033[1;32m  ⚡ antiGem Go IDE Server & AGY Hub Supervisor\033[0m")
	fmt.Println("\033[1;36m============================================================\033[0m")
	fmt.Printf("  \033[1m• IDE Server Port:\033[0m  http://%s:%s\n", cfg.Bind, cfg.Port)
	fmt.Printf("  \033[1m• Projects Dir:\033[0m     %s\n", cfg.ProjectsBaseDir)
	fmt.Printf("  \033[1m• Target Hub Port:\033[0m  %s\n", hubPort)
	if resolvedAgyBin != "" {
		fmt.Printf("  \033[1m• AGY Binary:\033[0m       %s\n", resolvedAgyBin)
	}
	fmt.Printf("  \033[1;33m• Security Token:\033[0m   %s\n", secToken)
	fmt.Printf("  \033[1;36m• Framed Header:\033[0m    %s\n", framedHeader)
	fmt.Printf("  \033[1m• Local Time:\033[0m       %s\n", time.Now().Format("2006-01-02 15:04:05 MST"))
	if runLogFile != nil {
		fmt.Printf("  \033[1m• Log File:\033[0m         %s\n", runLogFile.Path)
	}
	fmt.Println("\033[1;36m============================================================\033[0m")

	var hubMgr *hub.HubManager

	wsHub := ws.NewHub(cfg)
	h := handlers.NewHandler(cfg, hubMgr)
	h.SetHub(wsHub)

	mux := http.NewServeMux()

	// Claude Code CLI sessions (process manager + NDJSON WebSocket relay); off with --no-claude
	var claudeMgr *claude.Manager
	if noClaude {
		mux.HandleFunc("/api/claude/", func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte(`{"success":false,"disabled":true,"error":"Claude Code is turned off in the app"}`))
		})
	} else {
		claudeMgr = claude.NewManager(cfg.HomeDir, cfg.WorkspaceDir, customClaudeBin)
		mux.Handle("/api/claude/", claudeMgr)
	}

	// OpenCode: one `opencode serve` for all its chats, relayed under /api/opencode/x/; off with --no-opencode
	var openCodeMgr *opencode.Manager
	if noOpenCode {
		mux.HandleFunc("/api/opencode/", func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte(`{"success":false,"disabled":true,"error":"OpenCode is turned off in the app"}`))
		})
	} else {
		openCodeMgr = opencode.NewManager(cfg.HomeDir, cfg.WorkspaceDir, customOpenCodeBin)
		mux.Handle("/api/opencode/", openCodeMgr)
	}

	// Codex: one `codex app-server` (JSON-RPC over stdio, no port) for all its chats; off with --no-codex
	var codexMgr *codex.Manager
	if noCodex {
		mux.HandleFunc("/api/codex/", func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte(`{"success":false,"disabled":true,"error":"Codex is turned off in the app"}`))
		})
	} else {
		codexMgr = codex.NewManager(cfg.HomeDir, cfg.WorkspaceDir, customCodexBin)
		mux.Handle("/api/codex/", codexMgr)
	}

	// Project checkpoints: a hidden copy of the project before each chat message (any agent), restore with preview
	mux.Handle("/api/checkpoints/", checkpoint.NewManager(cfg.HomeDir))

	// Agent memory: memory files and chat history the agents read (~/.antigem/memory), shared by every agent
	mux.Handle("/api/memory/", memory.NewManager(cfg.HomeDir))

	// Custom AntiGem plugins on disk: list, install (ZIP or GitHub repository), update, remove, export
	pluginMgr := plugins.NewManager(cfg.HomeDir)
	mux.Handle("/api/custom-plugins/", pluginMgr)

	// Each agent's own skills folder (add from GitHub, update, remove) and Antigravity plugins from GitHub
	mux.Handle("/api/agent-skills/", plugins.NewAgentSkills(pluginMgr, cfg.HomeDir, func() string {
		if hubMgr != nil {
			if p := hubMgr.GetAgyBin(); p != "" {
				return p
			}
		}
		return hub.InstallerAgyPath()
	}))

	// REST Endpoints
	mux.HandleFunc("/api/health", h.HealthHandler)
	mux.HandleFunc("/api/status", h.StatusHandler)
	mux.HandleFunc("/api/shutdown", h.ShutdownHandler)
	mux.HandleFunc("/api/auth/login-url", h.GetLoginURLHandler)
	mux.HandleFunc("/api/auth/start-login", h.StartLoginHandler)
	mux.HandleFunc("/api/auth/forward-callback", h.ForwardLoginCallbackHandler)
	mux.HandleFunc("/api/server/info", h.ServerInfoHandler)
	mux.HandleFunc("/api/agy/cli", h.AgyCliHandler)
	mux.HandleFunc("/api/agy/cli/install", h.AgyCliInstallHandler)
	mux.HandleFunc("/api/agy/cli/update", h.AgyCliUpdateHandler)
	mux.HandleFunc("/api/agy/hub/diag", h.AgyHubDiagHandler)
	mux.HandleFunc("/api/agy/accounts", h.AgyAccountsHandler)
	mux.HandleFunc("/api/agy/accounts/", h.AgyAccountsHandler)
	mux.HandleFunc("/api/models", h.ModelsHandler)
	mux.HandleFunc("/api/models/refresh", h.ModelsHandler)
	mux.HandleFunc("/api/quotas", h.QuotasHandler)
	mux.HandleFunc("/api/quotas/refresh", h.QuotasHandler)
	mux.HandleFunc("/api/instances", h.InstancesHandler)
	mux.HandleFunc("/api/abort", h.AbortHandler)
	mux.HandleFunc("/api/conversations", h.ConversationsHandler)
	mux.HandleFunc("/api/system-prompt", h.SystemPromptHandler)
	mux.HandleFunc("/api/projects", h.ProjectsHandler)
	mux.HandleFunc("/api/projects/add", h.ProjectsAddHandler)
	mux.HandleFunc("/api/projects/remove", h.ProjectsRemoveHandler)
	mux.HandleFunc("/api/projects/create", h.CreateProjectHandler)
	mux.HandleFunc("/api/fs/browse", h.FsBrowseHandler)
	mux.HandleFunc("/api/fs/mkdir", h.FsMkdirHandler)
	// Files screen (explorer): places, details, safe create / rename, batch copy / move / delete, zip, unzip, search, streaming
	mux.HandleFunc("/api/fs/roots", h.FsRootsHandler)
	mux.HandleFunc("/api/fs/stat", h.FsStatHandler)
	mux.HandleFunc("/api/fs/new", h.FsNewHandler)
	mux.HandleFunc("/api/fs/rename", h.FsRenameHandler)
	mux.HandleFunc("/api/fs/chmod", h.FsChmodHandler)
	mux.HandleFunc("/api/fs/transfer", h.FsTransferHandler)
	mux.HandleFunc("/api/fs/delete", h.FsDeleteHandler)
	mux.HandleFunc("/api/fs/compress", h.FsCompressHandler)
	mux.HandleFunc("/api/fs/extract", h.FsExtractHandler)
	mux.HandleFunc("/api/fs/archive/list", h.FsArchiveListHandler)
	mux.HandleFunc("/api/fs/search", h.FsSearchHandler)
	mux.HandleFunc("/api/fs/raw", h.FsRawHandler)
	mux.HandleFunc("/api/fs/upload", h.FsUploadHandler)
	mux.HandleFunc("/api/tree", h.FileTreeHandler)
	mux.HandleFunc("/api/file/read", h.FileReadHandler)
	mux.HandleFunc("/api/file/save", h.FileSaveHandler)
	mux.HandleFunc("/api/file/patch", h.FilePatchHandler)
	mux.HandleFunc("/api/file/create", h.FileCreateHandler)
	mux.HandleFunc("/api/file/delete", h.FileDeleteHandler)
	mux.HandleFunc("/api/file/rename", h.FileRenameHandler)
	mux.HandleFunc("/api/file/copy", h.FileCopyHandler)
	mux.HandleFunc("/api/search", h.FileSearchHandler)
	mux.HandleFunc("/api/upload", h.UploadHandler)
	mux.HandleFunc("/api/mcp/config", h.McpConfigHandler)

	// Git Source Control Endpoints
	mux.HandleFunc("/api/git/status", h.GitStatusHandler)
	mux.HandleFunc("/api/git/init", h.GitInitHandler)
	mux.HandleFunc("/api/git/clone", h.GitCloneHandler)
	mux.HandleFunc("/api/git/config", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost {
			h.GitSetConfigHandler(w, r)
		} else {
			h.GitGetConfigHandler(w, r)
		}
	})
	mux.HandleFunc("/api/git/branches", h.GitBranchesHandler)
	mux.HandleFunc("/api/git/checkout", h.GitCheckoutHandler)
	mux.HandleFunc("/api/git/branch/create", h.GitCheckoutHandler)
	mux.HandleFunc("/api/git/stage", h.GitStageHandler)
	mux.HandleFunc("/api/git/unstage", h.GitUnstageHandler)
	mux.HandleFunc("/api/git/discard", h.GitDiscardHandler)
	mux.HandleFunc("/api/git/commit", h.GitCommitHandler)
	mux.HandleFunc("/api/git/push", h.GitPushHandler)
	mux.HandleFunc("/api/git/pull", h.GitPullHandler)
	mux.HandleFunc("/api/git/stash", h.GitStashHandler)
	mux.HandleFunc("/api/git/stash/pop", h.GitStashPopHandler)
	mux.HandleFunc("/api/git/diff", h.GitDiffHandler)
	mux.HandleFunc("/api/git/log", h.GitLogHandler)
	mux.HandleFunc("/api/git/commit/details", h.GitCommitDetailsHandler)
	mux.HandleFunc("/api/git/commit/diff", h.GitCommitFileDiffHandler)
	mux.HandleFunc("/api/git/commit/content", h.GitCommitFileContentHandler)

	// Sub-resource endpoints
	mux.HandleFunc("/api/instances/", func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, "/terminate") {
			h.TerminateInstanceHandler(w, r)
		} else {
			h.InstancesHandler(w, r)
		}
	})

	mux.HandleFunc("/api/conversations/restore", h.RestoreConversationHandler)
	mux.HandleFunc("/api/conversations/import", h.RestoreConversationHandler)

	mux.HandleFunc("/api/conversations/", func(w http.ResponseWriter, r *http.Request) {
		path := r.URL.Path
		if strings.HasSuffix(path, "/system-prompt") {
			h.SystemPromptHandler(w, r)
		} else if strings.HasSuffix(path, "/title") {
			h.UpdateConversationTitleHandler(w, r)
		} else if strings.HasSuffix(path, "/warm") {
			h.PrewarmConversationHandler(w, r)
		} else if strings.HasSuffix(path, "/export") || strings.HasSuffix(path, "/share") {
			h.ExportConversationArchiveHandler(w, r)
		} else {
			switch r.Method {
			case http.MethodGet:
				h.ConversationMessagesHandler(w, r)
			case http.MethodPatch, http.MethodPost:
				h.UpdateConversationTitleHandler(w, r)
			case http.MethodDelete:
				h.DeleteConversationHandler(w, r)
			default:
				http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			}
		}
	})

	// Static File Serving
	mux.Handle("/artifacts/", h.ArtifactsFileServer())
	mux.Handle("/attachments/", h.AttachmentsFileServer())

	// WebSocket Endpoint
	mux.HandleFunc("/ws", wsHub.ServeWS)

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if strings.ToLower(r.Header.Get("Upgrade")) == "websocket" {
			wsHub.ServeWS(w, r)
			return
		}
		if r.URL.Path == "/" {
			w.Header().Set("Content-Type", "text/plain")
			_, _ = w.Write([]byte(fmt.Sprintf("antiGem IDE Server running on :%s\n", cfg.Port)))
			return
		}
		http.NotFound(w, r)
	})

	corsHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
		// "*" lets any request header through without ever naming the secret one
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization, *")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}
		security.AuthMiddleware(secToken, mux).ServeHTTP(w, r)
	})

	// Global Panic Recovery & Error Logging Middleware:
	// 1. Prevents any API handler panic or crash from bringing down the Go server
	// 2. Formats and prints truncated request payload, query params, and error details to stdout/log stream
	recoveryHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Bypass recorder for WebSocket upgrade requests so Gorilla websocket can hijack directly
		if strings.ToLower(r.Header.Get("Upgrade")) == "websocket" || r.URL.Path == "/ws" {
			defer func() {
				if p := recover(); p != nil {
					log.Printf("\033[1;31m[WS CRASH / PANIC RECOVERED] %s: %v\033[0m\n", r.URL.Path, p)
					debug.PrintStack()
				}
			}()
			corsHandler.ServeHTTP(w, r)
			return
		}

		var reqPayload string
		// raw uploads (Files screen) can be gigabytes: never read them into memory for logging
		if r.Body != nil && !strings.HasPrefix(r.Header.Get("Content-Type"), "multipart/form-data") &&
			!strings.HasPrefix(r.Header.Get("Content-Type"), "application/octet-stream") {
			bodyBytes, err := io.ReadAll(r.Body)
			if err == nil && len(bodyBytes) > 0 {
				r.Body = io.NopCloser(bytes.NewReader(bodyBytes))
				trimmed := strings.TrimSpace(string(bodyBytes))
				if len(trimmed) > 300 {
					reqPayload = trimmed[:300] + "... (truncated)"
				} else {
					reqPayload = trimmed
				}
			}
		}

		rec := &statusRecorder{
			ResponseWriter: w,
			statusCode:     http.StatusOK,
		}

		defer func() {
			if p := recover(); p != nil {
				rawStack := debug.Stack()
				reason, codeLoc := formatHumanCrash(p, rawStack)

				log.Printf("\033[1;31m═══════════════════════════════════════════════════════════════\033[0m\n")
				log.Printf("\033[1;31m[API CRASH RECOVERED SAFELY] %s %s\033[0m\n", r.Method, r.URL.Path)
				if r.URL.RawQuery != "" {
					log.Printf("  \033[1;33m• Query:\033[0m    %s\n", r.URL.RawQuery)
				}
				if reqPayload != "" {
					log.Printf("  \033[1;33m• Payload:\033[0m  %s\n", reqPayload)
				}
				log.Printf("  \033[1;31m• Reason:\033[0m   %s\n", reason)
				log.Printf("  \033[1;36m• Code Line:\033[0m %s\n", codeLoc)
				log.Printf("\033[1;31m═══════════════════════════════════════════════════════════════\033[0m\n")

				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(map[string]interface{}{
					"error":    fmt.Sprintf("Internal Server Error: %s", reason),
					"location": codeLoc,
					"success":  false,
				})
			}
		}()

		corsHandler.ServeHTTP(rec, r)

		// Log API errors (status >= 400 or response payload containing "error" / "success":false)
		respStr := rec.responseBody.String()
		isErrorResp := rec.statusCode >= 400 || (strings.Contains(respStr, `"error"`) && strings.Contains(respStr, `"success":false`))
		if isErrorResp {
			log.Printf("\033[1;33m[API ERROR %d] %s %s\033[0m\n", rec.statusCode, r.Method, r.URL.Path)
			if r.URL.RawQuery != "" {
				log.Printf("  \033[33m• Query:\033[0m   %s\n", r.URL.RawQuery)
			}
			if reqPayload != "" {
				log.Printf("  \033[33m• Payload:\033[0m %s\n", reqPayload)
			}
			if len(respStr) > 0 {
				respSnippet := strings.TrimSpace(respStr)
				if len(respSnippet) > 300 {
					respSnippet = respSnippet[:300] + "... (truncated)"
				}
				log.Printf("  \033[31m• Error Response:\033[0m %s\n", respSnippet)
			}
		}
	})

	server := &http.Server{
		Addr:    net.JoinHostPort(cfg.Bind, cfg.Port),
		Handler: security.GuardResponse(secToken, recoveryHandler),
		// No whole-request Read/Write timeouts: over a real network (phone -> VPS) large uploads,
		// exports and streamed downloads legitimately take longer than a minute.
		ReadHeaderTimeout: 20 * time.Second,
		IdleTimeout:       180 * time.Second,
	}

	stopChan := make(chan os.Signal, 1)
	signal.Notify(stopChan, os.Interrupt, syscall.SIGTERM)

	h.OnShutdown = func() {
		log.Println("🛑 Received /api/shutdown request. Initiating graceful shutdown...")
		select {
		case stopChan <- syscall.SIGTERM:
		default:
		}
	}

	go func() {
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v", err)
		}
	}()

	fmt.Printf(" \033[32m🚀 antiGem IDE Server running at http://%s:%s\033[0m\n\n", cfg.Bind, cfg.Port)

	// Determine if AGY Hub should be started
	shouldStartHub := false
	if !skipHub {
		if forceStart {
			fmt.Println(" \033[33m⚡ Force flag (-f) detected: auto-starting AGY Hub...\033[0m")
			shouldStartHub = true
		} else {
			// Interactive user prompt
			fmt.Print(" \033[1;33m? Do you want to start AGY Hub server (port " + hubPort + ")? [Y/n]: \033[0m")
			reader := bufio.NewReader(os.Stdin)
			input, err := reader.ReadString('\n')
			if err == nil {
				trimmed := strings.ToLower(strings.TrimSpace(input))
				if trimmed == "" || trimmed == "y" || trimmed == "yes" {
					shouldStartHub = true
				} else {
					fmt.Println(" \033[90mℹ Skipping AGY Hub. Running IDE Server only.\033[0m")
				}
			} else {
				// Non-interactive fallback (e.g. piped or redirected stdin) -> default to starting hub
				shouldStartHub = true
			}
		}
	}

	// Always initialize HubManager (the handlers use it); with --no-hub it is disabled: no monitoring, no probes
	hubMgr = hub.NewHubManager(hubPort, cfg.WorkspaceDir, cfg.AppDataDir, secToken, resolvedAgyBin)
	if skipHub {
		hubMgr.Disabled = true
		hubMgr.SetStopped()
	}
	h.HubManager = hubMgr
	wsHub.StatusProv = hubMgr
	wsHub.HubPort = hubPort
	hubMgr.OnLoginURL = h.HandleLoginURL
	hubMgr.OnStatusChange = func(status string, csrfToken string, errorMsg string, logs []string) {
		wsHub.BroadcastHubStatus(status, hubPort, csrfToken, errorMsg, logs)
		// agy runs, so it is installed: watch its login for account changes (no-op when already watching)
		if status == hub.HubStatusOnline {
			h.EnsureAgyAccountWatcher()
		}
	}
	if !skipHub {
		hubMgr.StartContinuousMonitor()
	}

	if shouldStartHub {
		if err := hubMgr.Start(); err != nil {
			fmt.Printf(" \033[31m[!] Warning starting AGY Hub:\033[0m %v\n", err)
		}
	}

	<-stopChan
	fmt.Println("\n🛑 Shutting down antiGem server gracefully...")

	// 1. Close all active WebSocket client connections immediately
	h.StopAgyAccountWatcher()
	wsHub.Close()

	// 2. Stop Claude Code sessions, then the AGY Hub process group and continuous background monitor
	if claudeMgr != nil {
		claudeMgr.StopAll()
	}
	if openCodeMgr != nil {
		openCodeMgr.StopAll()
	}
	if codexMgr != nil {
		codexMgr.StopAll()
	}
	if hubMgr != nil {
		hubMgr.Stop()
	}

	// 3. Close the HTTP listener without hanging on lingering connections
	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()
	_ = server.Shutdown(ctx)
	_ = server.Close()

	fmt.Println("✅ antiGem Go server stopped.")
	runLogFile.Close()
	os.Exit(0)
}
