package ai.antigem.ui.chat

import androidx.compose.runtime.Immutable
import ai.antigem.domain.model.ChatMessage
import ai.antigem.domain.model.MessageRole
import ai.antigem.ui.components.MarkdownBlock
import ai.antigem.ui.components.parseMarkdownBlocks
import ai.antigem.ui.components.CodeBlockCache
import ai.antigem.ui.components.MarkdownTextCache
import java.util.concurrent.ConcurrentHashMap

@Immutable
sealed class ChatFeedItem(val key: String, val contentType: String) {
    @Immutable
    data class Summary(val message: ChatMessage) : ChatFeedItem("summary_${message.id}", "SUMMARY")
    @Immutable
    data class User(val message: ChatMessage) : ChatFeedItem("user_${message.id}", "USER")
    /** News Jarvis' teams sent to a Jarvis chat (shown as a card, not as the user's words). */
    @Immutable
    data class JarvisEvent(val message: ChatMessage) : ChatFeedItem("jarvis_event_${message.id}", "JARVIS_EVENT")
    @Immutable
    data class AssistantThinking(val messageId: String, val thoughtText: String, val durationMs: Long?, val isStreaming: Boolean) : ChatFeedItem("thought_$messageId", "THOUGHT")
    @Immutable
    data class AssistantBlock(val messageId: String, val blockIndex: Int, val block: MarkdownBlock, val isFirst: Boolean, val isLast: Boolean) : ChatFeedItem("block_${messageId}_$blockIndex", block.javaClass.simpleName)
    @Immutable
    data class AssistantTyping(val messageId: String, val modelId: String) : ChatFeedItem("active_assistant_typing", "TYPING")
    @Immutable
    data class AssistantFooter(val message: ChatMessage) : ChatFeedItem("footer_${message.id}", "FOOTER")
    @Immutable
    data class StreamingMessage(val message: ChatMessage) : ChatFeedItem("streaming_${message.id}", "STREAMING")
    /** A wavy-line divider with a label: a new day, or a model switch. */
    @Immutable
    data class Divider(val id: String, val label: String) : ChatFeedItem("divider_$id", "DIVIDER")
    /**
     * An Antigravity voice call in the chat, as a wavy-line divider ("Voice call · 2:11 PM · 3m 01s"): a saved call
     * opens its transcript ([record]); a [live] one opens the call.
     */
    @Immutable
    data class VoiceCall(
        val id: String,
        val startedAt: Long,
        val durationMs: Long?,
        val live: Boolean,
        val record: ai.antigem.data.voice.VoiceChatRecord?
    ) : ChatFeedItem("voicecall_$id", "VOICE_CALL")
}

object ChatFeedCache {
    val cache = ConcurrentHashMap<String, List<ChatFeedItem>>()

    fun getOrParse(msg: ChatMessage): List<ChatFeedItem> {
        val cacheKey = "${msg.id}_${msg.content.hashCode()}_${msg.toolCalls.hashCode()}_${msg.thoughtText?.hashCode() ?: 0}_${msg.tokenUsage?.hashCode() ?: 0}"
        val cached = cache[cacheKey]
        if (cached != null) return cached

        val msgItems = mutableListOf<ChatFeedItem>()
        when (msg.role) {
            MessageRole.SUMMARY -> {
                msgItems.add(ChatFeedItem.Summary(msg))
            }
            MessageRole.USER -> {
                if (ai.antigem.data.jarvis.JarvisEvents.isEventMessage(msg.content)) {
                    msgItems.add(ChatFeedItem.JarvisEvent(msg))
                } else {
                    // Show the slash command the user typed, not the instructions it expanded to
                    val shown = ai.antigem.data.remote.PromptExpansion.collapse(msg.content)
                    // (the full text stays along for "View full prompt")
                    msgItems.add(ChatFeedItem.User(if (shown === msg.content) msg else msg.copy(content = shown, sentContent = msg.content)))
                }
            }
            MessageRole.ASSISTANT -> {
                val durTag = if (msg.thoughtDurationMs != null && msg.thoughtDurationMs > 0) ":${msg.thoughtDurationMs}" else ""
                val contentToParse = if (!msg.thoughtText.isNullOrEmpty() && !msg.content.contains("<!-- thought") && !msg.content.contains("<thought")) {
                    "<!-- thought$durTag -->\n${msg.thoughtText}\n<!-- /thought -->\n${msg.content}"
                } else {
                    msg.content
                }
                if (contentToParse.isNotEmpty() || msg.toolCalls.isNotEmpty()) {
                    val blocks = parseMarkdownBlocks(contentToParse, msg.toolCalls)
                    for (i in blocks.indices) {
                        msgItems.add(ChatFeedItem.AssistantBlock(
                            messageId = msg.id,
                            blockIndex = i,
                            block = blocks[i],
                            isFirst = i == 0,
                            isLast = i == blocks.lastIndex
                        ))
                    }
                }
                if (msg.content.isNotEmpty()) {
                    msgItems.add(ChatFeedItem.AssistantFooter(msg))
                }
            }
            else -> {}
        }
        cache[cacheKey] = msgItems
        return msgItems
    }

    /**
     * Prewarm markdown blocks asynchronously on Dispatchers.Default for the most recent
     * window of messages (last 12 messages by default) so the UI thread has zero parsing work
     * during composition, without wasting memory/CPU on the entire chat history.
     */
    fun prewarm(messages: List<ChatMessage>, windowSize: Int = 12, isDark: Boolean = true) {
        if (messages.isEmpty()) return
        val targetMessages = if (messages.size > windowSize) messages.takeLast(windowSize) else messages
        for (msg in targetMessages) {
            if (!msg.isStreaming) {
                val items = getOrParse(msg)
                for (item in items) {
                    if (item is ChatFeedItem.AssistantBlock) {
                        when (val block = item.block) {
                            is MarkdownBlock.Code -> {
                                CodeBlockCache.prewarm(block.code, block.language)
                            }
                            is MarkdownBlock.Paragraph -> {
                                MarkdownTextCache.prewarm(block.text, isDark)
                            }
                            is MarkdownBlock.Header -> {
                                MarkdownTextCache.prewarm(block.text, isDark)
                            }
                            is MarkdownBlock.Bullet -> {
                                MarkdownTextCache.prewarm(block.text, isDark)
                            }
                            is MarkdownBlock.Numbered -> {
                                MarkdownTextCache.prewarm(block.text, isDark)
                            }
                            is MarkdownBlock.Blockquote -> {
                                MarkdownTextCache.prewarm(block.text, isDark)
                            }
                            is MarkdownBlock.Task -> {
                                MarkdownTextCache.prewarm(block.text, isDark)
                            }
                            else -> {}
                        }
                    }
                }
            }
        }
    }

    /**
     * The chat as list items. With [dividers], a divider goes before the first prompt of each new day ("Sat, Oct 10")
     * and before the prompt of a reply whose model differs from the previous reply's ("Switched to Sonnet 5.5";
     * [modelName] turns a model id into its display name).
     */
    fun buildFeedItems(
        messages: List<ChatMessage>,
        selectedModelId: String,
        dividers: Boolean = false,
        modelName: (String) -> String = { it },
        /** Antigravity voice calls of the chat, oldest first: each goes before the first prompt sent after it started. */
        voiceCalls: List<ChatFeedItem.VoiceCall> = emptyList()
    ): List<ChatFeedItem> {
        val result = ArrayList<ChatFeedItem>(messages.size * 3)
        val seenKeys = HashSet<String>()

        fun addItem(item: ChatFeedItem) {
            if (seenKeys.add(item.key)) {
                result.add(item)
            }
        }

        var lastDay: String? = null
        var lastPromptAt = 0L
        var lastModel: String? = null
        // where the latest prompt's items start: a model divider goes right before that prompt
        var promptStart = -1
        var nextCall = 0
        fun addCall(call: ChatFeedItem.VoiceCall) {
            if (dividers) {
                val day = dayKey(call.startedAt)
                if (day != lastDay) {
                    addItem(ChatFeedItem.Divider("day_$day", dayLabel(call.startedAt)))
                    lastDay = day
                }
            }
            addItem(call)
        }
        for (msg in messages) {
            if (msg.role == MessageRole.USER) {
                while (nextCall < voiceCalls.size && voiceCalls[nextCall].startedAt <= msg.createdAt) addCall(voiceCalls[nextCall++])
            }
            if (dividers && msg.role == MessageRole.USER) {
                val day = dayKey(msg.createdAt)
                if (day != lastDay) {
                    addItem(ChatFeedItem.Divider("day_$day", dayLabel(msg.createdAt)))
                    lastDay = day
                } else if (lastPromptAt > 0 && msg.createdAt - lastPromptAt >= GAP_DIVIDER_MS) {
                    addItem(ChatFeedItem.Divider("gap_${msg.id}", dayLabel(msg.createdAt)))
                }
                lastPromptAt = msg.createdAt
                promptStart = result.size
            }
            if (dividers && msg.role == MessageRole.ASSISTANT && msg.modelId != null) {
                val previous = lastModel
                if (previous != null && msg.modelId != previous) {
                    val divider = ChatFeedItem.Divider("model_${msg.id}", "Switched to ${modelName(msg.modelId)}")
                    if (seenKeys.add(divider.key)) result.add(if (promptStart >= 0) promptStart else result.size, divider)
                }
                lastModel = msg.modelId
            }
            // only the first reply after a prompt may put a divider before that prompt
            if (msg.role == MessageRole.ASSISTANT) promptStart = -1
            if (!msg.isStreaming) {
                val parsed = getOrParse(msg)
                for (item in parsed) {
                    addItem(item)
                }
            } else {
                val hasActiveRunningTool = msg.toolCalls.any {
                    it.status == "RUNNING" || it.status == "PENDING_APPROVAL" || it.status == "AWAITING_CHOICE"
                }
                val durTag = if (msg.thoughtDurationMs != null && msg.thoughtDurationMs > 0) ":${msg.thoughtDurationMs}" else ""
                val contentToParse = if (!msg.thoughtText.isNullOrEmpty() && !msg.content.contains("<!-- thought") && !msg.content.contains("<thought")) {
                    if (msg.content.isBlank()) {
                        "<!-- thought:streaming$durTag -->\n${msg.thoughtText}"
                    } else {
                        "<!-- thought:streaming$durTag -->\n${msg.thoughtText}\n<!-- /thought -->\n${msg.content}"
                    }
                } else {
                    msg.content
                }
                if (contentToParse.isNotEmpty() || msg.toolCalls.isNotEmpty()) {
                    val blocks = parseMarkdownBlocks(contentToParse, msg.toolCalls)
                    for (i in blocks.indices) {
                        addItem(ChatFeedItem.AssistantBlock(
                            messageId = msg.id,
                            blockIndex = i,
                            block = blocks[i],
                            isFirst = i == 0,
                            isLast = i == blocks.lastIndex
                        ))
                    }
                } else if (!hasActiveRunningTool) {
                    // Only show waiting indicator before ANY output or tool call has appeared
                    addItem(ChatFeedItem.AssistantTyping(msg.id, selectedModelId))
                }
            }
        }
        // calls after the last prompt (or a call going on now) close the chat
        while (nextCall < voiceCalls.size) addCall(voiceCalls[nextCall++])
        return result
    }

    fun clear() {
        cache.clear()
    }

    private fun dayKey(millis: Long): String {
        val c = java.util.Calendar.getInstance().apply { timeInMillis = millis }
        return "${c.get(java.util.Calendar.YEAR)}-${c.get(java.util.Calendar.DAY_OF_YEAR)}"
    }

    /** A prompt sent this long after the previous one on the same day gets a divider with the time. */
    private const val GAP_DIVIDER_MS = 60 * 60 * 1000L

    /** "Sat, Oct 10, 15:45" (24-hour time) in the phone's language; the year is added when it is not this year. */
    private fun dayLabel(millis: Long): String {
        val locale = java.util.Locale.getDefault()
        val thisYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        val year = java.util.Calendar.getInstance().apply { timeInMillis = millis }.get(java.util.Calendar.YEAR)
        val skeleton = (if (year == thisYear) "EEEMMMd" else "EEEMMMdyyyy") + "Hmm"
        val pattern = android.text.format.DateFormat.getBestDateTimePattern(locale, skeleton)
        return java.text.SimpleDateFormat(pattern, locale).format(java.util.Date(millis))
    }
}

@Immutable
data class ConversationScrollPosition(
    val index: Int,
    val offset: Int,
    val isNearBottom: Boolean
)

object ConversationScrollCache {
    private val scrollPositions = ConcurrentHashMap<String, ConversationScrollPosition>()

    fun save(convId: String, index: Int, offset: Int, isNearBottom: Boolean) {
        if (convId.isBlank() || convId == "empty") return
        scrollPositions[convId] = ConversationScrollPosition(index, offset, isNearBottom)
    }

    fun get(convId: String?): ConversationScrollPosition? {
        if (convId.isNullOrBlank() || convId == "empty") return null
        return scrollPositions[convId]
    }

    fun clear(convId: String) {
        scrollPositions.remove(convId)
    }

    fun clearAll() {
        scrollPositions.clear()
    }
}
